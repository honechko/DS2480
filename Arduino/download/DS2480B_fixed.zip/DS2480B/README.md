DS2480B Library for Arduino
=======================

Interfaces with DS2480B chip in order
to acquire access to the 1-wire bus over
serial